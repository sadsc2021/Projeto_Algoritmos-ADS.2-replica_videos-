//#############################

//Código do primeiro video

/*var avgTemp = [];

avgTemp[0] = 31.9
avgTemp[1] = 35.3
avgTemp[2] = 42
avgTemp[3] = 38
avgTemp[4] = 25.5

console.log(avgTemp[3]);*/

//###############################################

//Código do segundo video

/*var DayOfWeek = new Array("Sunday", "monday", "Tuesday", "Wednesday", "Thursday",
"Friday", "Saturday");

console.log(DayOfWeek[3]);*/

//###############################################

//Código do terceiro video

/*var DayOfWeek = ["Sunday", "monday", "Tuesday", "Wednesday", "Thursday",
"Friday", "Saturday"];

for(var i = 0; i < DayOfWeek.length; i++) {
    //console.log(DayOfWeek[i]);
}

var fibonacci = [];
fibonacci[0] = 0
fibonacci[1] = 1
fibonacci[2] = 1

for(var i = 3; i < 20; i++) {
    fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2]
    //console.log(fibonacci);
}

for(var i = 0; i < fibonacci.length; i++) {
    console.log(fibonacci[i]);
}*/

//######################################################

//Código do quarto video

/*
var numbers = [0,1,2,3,4,5,6,7,8,9]

numbers[numbers.length] = 10
numbers[numbers.length] = 11

numbers.push(12)
numbers.push(13)
numbers.push(14)
numbers.push(15)
numbers.push(16)

numbers.unshift(-1)
numbers.unshift(-2)
numbers.unshift(-3)
numbers.unshift(-4)

numbers[0] = -40
console.log(numbers)
*/
//########################################